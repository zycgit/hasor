package net.hasor.inject._exts;
public class TT {

    //    /** 加载带有 @DimModule 注解的类。 */
    //    default ApiBinder loadModule(Set<Class<?>> moduleTypes) {
    //        return this.loadModule(moduleTypes, AopMatchers.anyClass(), null);
    //    }
    //
    //    /** 加载带有 @DimModule 注解的类。 */
    //    default ApiBinder loadModule(Set<Class<?>> maybeModuleTypes, Predicate<Class<?>> matcher, TypeSupplier typeSupplier) {
    //        if (maybeModuleTypes != null && !maybeModuleTypes.isEmpty()) {
    //            maybeModuleTypes.stream()//
    //                    .filter(matcher)//
    //                    .filter(AopMatchers.annotatedWithClass(DimModule.class))//
    //                    .forEach(aClass -> loadModule(aClass, typeSupplier));
    //        }
    //        return this;
    //    }
    //
    //    /** 加载带有 @DimModule 注解的类。 */
    //    default ApiBinder loadModule(Class<?> moduleType) {
    //        return loadModule(moduleType, null);
    //    }
    //
    //    /** 加载带有 @DimModule 注解的类。 */
    //    default ApiBinder loadModule(Class<?> moduleType, final TypeSupplier typeSupplier) {
    //        Objects.requireNonNull(moduleType, "class is null.");
    //        int modifier = moduleType.getModifiers();
    //        if (BitUtils.checkOr(modifier, Modifier.INTERFACE, Modifier.ABSTRACT) || moduleType.isArray() || moduleType.isEnum()) {
    //            throw new IllegalStateException(moduleType.getName() + " must be normal Bean");
    //        }
    //        if (moduleType.getAnnotation(DimModule.class) == null) {
    //            throw new IllegalStateException(moduleType.getName() + " must be configure @DimModule");
    //        }
    //        if (!Module.class.isAssignableFrom(moduleType)) {
    //            throw new IllegalStateException(moduleType.getName() + " must be implements Module.");
    //        }
    //
    //        try {
    //            Class<? extends Module> newModuleType = (Class<? extends Module>) moduleType;
    //            if (typeSupplier != null) {
    //                installModule(typeSupplier.get(newModuleType));
    //            } else {
    //                installModule(newModuleType.newInstance());
    //            }
    //            return this;
    //        } catch (Throwable e) {
    //            throw ExceptionUtils.toRuntime(e);
    //        }
    //    }
    //
    //
    //
    //    /** 加载SPI监听器，可以在 spiType 上选择配置 @Spi 注解 */
    //    default void loadSpiListener(Set<Class<?>> spiTypeSet) {
    //        loadSpiListener(spiTypeSet, null);
    //    }
    //
    //    /** 加载SPI监听器，可以在 spiType 上选择配置 @Spi 注解 */
    //    default void loadSpiListener(Set<Class<?>> spiSupplierTypeSet, TypeSupplier typeSupplier) {
    //        if (spiSupplierTypeSet != null && !spiSupplierTypeSet.isEmpty()) {
    //            spiSupplierTypeSet.forEach(aClass -> loadSpiListener(aClass, typeSupplier));
    //        }
    //    }
    //
    //    /** 加载SPI监听器，可以在 spiType 上选择配置 @Spi 注解 */
    //    default void loadSpiListener(Class<?> spiSupplierType) {
    //        loadSpiListener(spiSupplierType, null);
    //    }
    //
    //    /** 加载SPI监听器，可以在 spiType 上选择配置 @Spi 注解 */
    //    default void loadSpiListener(Class<?> spiSupplierType, final TypeSupplier typeSupplier) {
    //        Objects.requireNonNull(spiSupplierType, "spiSupplierType is Null.");
    //        Spi apiAnnotation = spiSupplierType.getAnnotation(Spi.class);
    //        Class<?>[] allTypes = null;
    //        if (apiAnnotation == null || apiAnnotation.value().length == 0) {
    //            allTypes = ClassUtils.getAllInterfaces(spiSupplierType).toArray(new Class<?>[0]);
    //        } else {
    //            allTypes = apiAnnotation.value();
    //        }
    //        if (allTypes.length == 0) {
    //            return;
    //        }
    //
    //        Supplier<EventListener> spiSupplier = null;
    //        if (typeSupplier == null) {
    //            spiSupplier = (Supplier<EventListener>) getProvider(spiSupplierType);
    //        } else {
    //            spiSupplier = () -> (EventListener) typeSupplier.get(spiSupplierType);
    //        }
    //
    //        for (Class<?> spiTypeOri : allTypes) {
    //            Class<EventListener> spiType = (Class<EventListener>) spiTypeOri;
    //            this.bindSpiListener(spiType, spiSupplier);
    //        }
    //    }
    //
    //
    //
    //

    //    /**
    //     * 在框架扫描包的范围内查找具有特征类集合（特征可以是继承的类、标记的注解）。<br>
    //     *  -- 该方法会放弃在匹配的过程中如果类无法被ClassLoader所加载的类。
    //     * @param featureType 特征类型
    //     * @return 返回匹配的类集合。
    //     */
    //    Set<Class<?>> findClass(Class<?> featureType);
    //
    //    /**
    //     * 在框架扫描包的范围内查找具有特征类集合（特征可以是继承的类、标记的注解）。<br>
    //     *  -- 该方法会放弃在匹配的过程中如果类无法被ClassLoader所加载的类。
    //     * @param featureType 特征类型
    //     * @param scanPackages 扫描的包范围
    //     * @return 返回匹配的类集合。
    //     */
    //    Set<Class<?>> findClass(Class<?> featureType, String... scanPackages);
    //
    //
    // @Override
    //    public Set<Class<?>> findClass(final Class<?> featureType) {
    //        String[] spanPackage = this.settings. ()
    //                .getSpanPackage(); return this.getEnvironment().findClass(featureType, spanPackage);
    //    }
    //
    //    @Override
    //    public Set<Class<?>> findClass(final Class<?> featureType, final String... scanPackages) {
    //        if (featureType == null || scanPackages == null || scanPackages.length == 0) {
    //            return null;
    //        }
    //        return this.getEnvironment().findClass(featureType, scanPackages);
    //    }

    //
    //
    //
    //

}
